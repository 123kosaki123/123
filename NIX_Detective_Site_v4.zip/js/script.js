
// Matrix Effect
const canvas = document.getElementById('matrix');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
const cols = canvas.width / 20;
const drops = [];
for (let i = 0; i < cols; i++) drops[i] = canvas.height;
function draw() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#0f0';
    ctx.font = '16px monospace';
    for (let i = 0; i < drops.length; i++) {
        const text = String.fromCharCode(0x30A0 + Math.random() * 96);
        ctx.fillText(text, i * 20, drops[i]);
        drops[i] += 20;
        if (drops[i] > canvas.height || Math.random() > 0.975) drops[i] = 0;
    }
}
setInterval(draw, 50);

// Sidebar indicator
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.sidebar');
    const indicator = document.createElement('div');
    indicator.classList.add('sidebar-indicator');
    sidebar.appendChild(indicator);
    const links = sidebar.querySelectorAll('a');
    function updateIndicator(el) {
        indicator.style.top = el.offsetTop + 'px';
        indicator.style.height = el.offsetHeight + 'px';
    }
    const active = sidebar.querySelector('a.active') || links[0];
    updateIndicator(active);
    links.forEach(link => {
        link.addEventListener('click', e => {
            links.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            updateIndicator(link);
        });
    });
});
